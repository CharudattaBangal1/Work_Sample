﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace omnisearch
{
        public class DataClassParam
        {
            public string DocSearchParamId { get; set; }
            public string Value { get; set; }
        }

        public class Metadata
        {
            public Sender Sender { get; set; }
        }

        public class Root
        {
            public Metadata Metadata { get; set; }
            public List<SearchRequest> SearchRequest { get; set; }
            public string SourceSystemName { get; set; }
            public string SearchOperator { get; set; }
        }

        public class SearchRequest
        {
            public string CategoryID { get; set; }
            public object DocumentID { get; set; }
            public string ReferenceID { get; set; }
            public string FileName { get; set; }
            public string Description { get; set; }
            public List<DataClassParam> DataClassParam { get; set; }
        }

        public class Sender
        {
            public string LogicalID { get; set; }
            public string TaskID { get; set; }
            public string ReferenceID { get; set; }
            public string CreationDateTime { get; set; }
            public string TODID { get; set; }
        }
    }