﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace omnisearch
{
    public class searchres
    {
        public SearchResponse search(string response)
        {
            SearchResponse search = new SearchResponse();
            searchDataClassParam data = new searchDataClassParam();
            OmniSearch res = new JavaScriptSerializer() { MaxJsonLength = Int32.MaxValue }.Deserialize<OmniSearch>(response);
            if(data.DocSearchParamId == "2")
            {

            }
            if(data.DocSearchParamId == "3")
            {

            }
            {

            }


            return search;
            
        }
    }
}