﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
public class searchResDataClassParam
{
    public string DocSearchParamId { get; set; }
    public string Value { get; set; }
}

public class searchError
{
    public string Code { get; set; }
    public string Description { get; set; }
}

public class OmniSearchResponse
{
    public List<SearchResponse> SearchResponse { get; set; }
    public string CategoryID { get; set; }
    public string DocumentID { get; set; }
    public string ReferenceID { get; set; }
}

public class SearchResponse
{
    public string GlobalId { get; set; }
    public string OmniDocImageIndex { get; set; }
    public string OmniDocIndex { get; set; }
    public string VID { get; set; }
    public string FileName { get; set; }
    public string Description { get; set; }
    public string UploadedDate { get; set; }
    public List<searchResDataClassParam> DataClassParam { get; set; }
    public List<searchError> Error { get; set; }
}

