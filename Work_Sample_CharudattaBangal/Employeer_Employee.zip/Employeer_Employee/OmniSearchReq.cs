﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for clsOmniSearchReq
/// </summary>
public class OmniSearch
{
    public searchMetadata Metadata { get; set; }
    public List<SearchRequest> SearchRequest { get; set; }
    public string SourceSystemName { get; set; }
    public string SearchOperator { get; set; }
}
public class searchMetadata
{
    public searchSender Sender { get; set; }
}
public class searchSender
{
    public string LogicalID { get; set; }
    public string TaskID { get; set; }
    public string ReferenceID { get; set; }
    public string CreationDateTime { get; set; }
    public string TODID { get; set; }
}

public class SearchRequest
{
    public string CategoryID { get; set; }
    public string DocumentID { get; set; }
    public string ReferenceID { get; set; }
    public string FileName { get; set; }
    public string Description { get; set; }
    public List<searchDataClassParam> DataClassParam { get; set; }
}
public class searchDataClassParam
{
    public string DocSearchParamId { get; set; }
    public string Value { get; set; }
}
//public class DataClassParam
//{
//    public string DocSearchParamId { get; set; }
//    public string Value { get; set; }
//}

