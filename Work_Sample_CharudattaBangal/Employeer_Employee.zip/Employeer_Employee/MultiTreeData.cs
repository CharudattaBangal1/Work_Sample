﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace omnisearch
{
    public class MultiTreeData
    {
        public List<TreeNode3> myData { get; set; }
    }

    public class TreeNode3
    {
        public string id { get; set; }
        public string text { get; set; }
        public string url { get; set; }
        public string icon { get; set; }
        public bool isFolder { get; set; } // Indicates whether it's a folder
        public List<TreeNode3> children { get; set; }
    }
}