﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace omnisearch
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class DataClassParamResp
    {
        public string DocSearchParamId { get; set; }
        public string Value { get; set; }
    }

    public class Error
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }

    public class SearchResponse
    {
        public string GlobalId { get; set; }
        public string OmniDocImageIndex { get; set; }
        public string OmniDocIndex { get; set; }
        public string VID { get; set; }
        public string FileName { get; set; }
        public string Description { get; set; }
        public string UploadedDate { get; set; }
        public List<DataClassParam> DataClassParam { get; set; }
        public List<Error> Error { get; set; }
    }

    public class Response
    {
        public List<SearchResponse> SearchResponse { get; set; }
        public string CategoryId { get; set; }
        public string DocumentId { get; set; }
        public string ReferenceId { get; set; }
    }


}